/**
 * Project CC3k - Fall 2015
 * @author Nian Liu and Jiancheng Chen
 */


#include "stair.h"

/**
 * Stair implementation
 */

Stair::Stair() : Object('\\', "stair") {}

Stair::~Stair() {}
