/**
 * Project CC3k - Fall 2015
 * @author Nian Liu and Jiancheng Chen
 */


#ifndef _STAIR_H
#define _STAIR_H

#include "object.h"


class Stair: public Object {
public: 
	Stair();
	
	~Stair();
};

#endif //_STAIR_H
